import Foundation
import UniformTypeIdentifiers
#if os(macOS)
import AppKit
typealias PlatformController = NSViewController
#else
import UIKit
typealias PlatformController = UIViewController
#endif

final class ShareViewController: PlatformController {
    private var began = false
    #if os(macOS)
    override func loadView() { view = NSView(frame: NSRect(x: 0, y: 0, width: 360, height: 180)) }
    #endif
    #if os(macOS)
    override func viewDidAppear() {
        super.viewDidAppear()
        begin()
    }
    #else
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        begin()
    }
    #endif
    private func begin() {
        guard !began else { return }; began = true
        Task { @MainActor in await receive() }
    }
    @MainActor private func receive() async {
        do {
            let items = extensionContext?.inputItems as? [NSExtensionItem] ?? []
            var pieces: [String] = []; var sourceURL = ""
            for item in items {
                if let content = item.attributedContentText?.string, !content.isEmpty { pieces.append(content) }
                for provider in item.attachments ?? [] {
                    if provider.hasItemConformingToTypeIdentifier(UTType.url.identifier) {
                        let value = try await load(provider, type: UTType.url.identifier)
                        let url = (value as? URL)?.absoluteString ?? (value as? String) ?? ""
                        if url.hasPrefix("https://") || url.hasPrefix("http://") { if sourceURL.isEmpty { sourceURL = url }; pieces.append(url) }
                    } else if provider.hasItemConformingToTypeIdentifier(UTType.plainText.identifier) {
                        let value = try await load(provider, type: UTType.plainText.identifier)
                        if let text = value as? String { pieces.append(text) }
                        else if let data = value as? Data, let text = String(data: data, encoding: .utf8) { pieces.append(text) }
                    }
                }
            }
            var seen = Set<String>(); pieces = pieces.filter { !$0.isEmpty && seen.insert($0).inserted }
            let text = pieces.joined(separator: "\n\n")
            guard !text.isEmpty, text.count <= 20000 else { throw InboxError.server("Share text or a web link up to 20,000 characters.") }
            let idea = Idea(body: text, url: sourceURL)
            try SharedInbox.queue(idea)
            do { try await SharedInbox.send(idea); show("Idea saved", detail: "Saved to your inbox. No chat was started.") }
            catch { show("Idea queued", detail: "Saved on this device. Open Thread Inbox to sync when connected.") }
        } catch { show("Could not save", detail: error.localizedDescription, success: false) }
    }
    private func load(_ provider: NSItemProvider, type: String) async throws -> NSSecureCoding? {
        try await withCheckedThrowingContinuation { continuation in
            provider.loadItem(forTypeIdentifier: type, options: nil) { value, error in
                if let error { continuation.resume(throwing: error) } else { continuation.resume(returning: value) }
            }
        }
    }
    @MainActor private func show(_ title: String, detail: String, success: Bool = true) {
        #if os(macOS)
        let alert = NSAlert(); alert.messageText = title; alert.informativeText = detail; alert.addButton(withTitle: "Done")
        if let window = view.window { alert.beginSheetModal(for: window) { _ in self.finish(success) } }
        else { finish(success) }
        #else
        let alert = UIAlertController(title: title, message: detail, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Done", style: .default) { _ in self.finish(success) }); present(alert, animated: true)
        #endif
    }
    private func finish(_ success: Bool) {
        if success { extensionContext?.completeRequest(returningItems: nil) }
        else { extensionContext?.cancelRequest(withError: InboxError.server("Share was not saved.")) }
    }
}
