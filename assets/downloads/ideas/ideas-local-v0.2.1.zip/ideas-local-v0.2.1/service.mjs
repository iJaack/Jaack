import { createServer } from 'node:http';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { execFile } from 'node:child_process';
import { readFileSync, writeFileSync, existsSync, statSync, renameSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Store, fail, closed } from './store.mjs';
import { handleMCP } from './plugin/server.mjs';

export const defaultDirectory = () => process.env.THREAD_INBOX_DATA || join(homedir(), 'Library/Application Support/Thread Inbox');
export function configuration(directory) {
  const path = join(directory,'connection.json');
  if (!existsSync(path)) writeFileSync(path, JSON.stringify({adminToken:randomBytes(32).toString('hex'),captureToken:randomBytes(32).toString('hex')}), {mode:0o600,flag:'wx'});
  if (!statSync(path).isFile() || statSync(path).mode & 0o077) fail('connection.json must be a private file',500);
  const value=JSON.parse(readFileSync(path,'utf8'));
  if (![value.adminToken,value.captureToken].every(v=>typeof v==='string'&&/^[0-9a-f]{64}$/.test(v))) fail('Invalid private connection file',500);
  return value;
}
const equals = (a,b) => Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
async function body(req) {
  if (!/^application\/json(?:;|$)/i.test(req.headers['content-type']||'')) fail('Use application/json',415);
  const chunks=[]; let size=0;
  for await (const chunk of req) { size+=chunk.length; if(size>2*1024*1024) fail('Request too large',413); chunks.push(chunk); }
  try { return JSON.parse(Buffer.concat(chunks).toString()); } catch { fail('Invalid JSON'); }
}
export function createInboxServer(directory, options={}) {
  const store = new Store(directory); const config=configuration(directory);
  const root=dirname(fileURLToPath(import.meta.url));
  const appleApp=join(root,'Ideas Sources.app');
  const connector=()=>{let value={state:'disconnected'};try{value=JSON.parse(readFileSync(join(directory,'apple-connector-status.json'),'utf8'));}catch{}return{...value,installed:existsSync(appleApp)};};
  const server=createServer(async(req,res)=>{
    const send=(status,value)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(value));};
    try {
      const url=new URL(req.url,'http://localhost');
      if(req.method==='GET'&&url.pathname==='/') {
        res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});
        res.end(readFileSync(join(root,'web/inbox.html')));return;
      }
      if(req.headers.origin && ![`http://${req.headers.host}`,options.publicOrigin].includes(req.headers.origin)) fail('Origin refused',403);
      const token=(req.headers.authorization||'').replace(/^Bearer /,'');
      const admin=equals(token,config.adminToken), capture=equals(token,config.captureToken);
      if(!admin && !capture) fail('Pair this device with the inbox first',401);
      if(url.pathname==='/mcp') {
        if(!admin)fail('Remote plugin access requires the owner connection token',403);
        if(req.method!=='POST'){res.writeHead(405,{'Allow':'POST','Cache-Control':'no-store'});res.end();return;}
        const q=await body(req);
        if(!q||q.jsonrpc!=='2.0'||typeof q.method!=='string'||(Object.hasOwn(q,'id')&&typeof q.id!=='number'&&typeof q.id!=='string'))fail('Invalid MCP message');
        if(!Object.hasOwn(q,'id')){res.writeHead(204);res.end();return;}
        try {
          const result=await handleMCP(q,async(method,path,value)=>{
            const r=await fetch(`http://127.0.0.1:${server.address().port}${path}`,{method,headers:{Authorization:`Bearer ${config.adminToken}`,'Content-Type':'application/json'},body:value===undefined?undefined:JSON.stringify(value),redirect:'error',signal:AbortSignal.timeout(15000)});
            const data=await r.json();if(!r.ok)throw Error(data.error||'Inbox refused');return data;
          });
          send(200,{jsonrpc:'2.0',id:q.id,result});
        }catch(e){send(200,{jsonrpc:'2.0',id:q.id,error:{code:e.code||-32600,message:e.message}});}
        return;
      }
      if(req.method==='GET'&&url.pathname==='/api/items') {send(200,{...store.list(url.searchParams.get('kind')||'all',Number(url.searchParams.get('limit')||50),Number(url.searchParams.get('offset')||0),url.searchParams.get('query')||''),connector:connector()});return;}
      if(req.method==='GET'&&url.pathname.startsWith('/api/item/')) {const item=store.get(decodeURIComponent(url.pathname.slice(10)));if(!item)fail('Item missing',404);send(200,item);return;}
      if(req.method==='POST'&&url.pathname==='/api/ideas'){send(200,{status:'verified',record:store.idea(await body(req))});return;}
      if(req.method==='POST'&&url.pathname==='/api/chat-requests'){send(200,store.prepare(await body(req)));return;}
      if(!admin) fail('This operation requires the Mac connection token',403);
      if(req.method==='POST'&&url.pathname==='/api/apple/sync') {
        const value=await body(req);closed(value,['action']);if(!['connect','refresh'].includes(value.action))fail('Invalid source action');
        if(process.platform!=='darwin'||!existsSync(appleApp))fail('Install the local Ideas Sources connector first',503);
        const request={requestId:randomUUID(),action:value.action,createdAt:new Date().toISOString().replace(/\.\d{3}Z$/,'Z')};
        const path=join(directory,'apple-request.json');writeFileSync(path+'.tmp',JSON.stringify(request),{mode:0o600});renameSync(path+'.tmp',path);
        await new Promise((resolve,reject)=>execFile('/usr/bin/open',['-g',appleApp],{timeout:10000},e=>e?reject(e):resolve()));
        send(200,{status:'requested',requestId:request.requestId});return;
      }
      if(req.method==='POST'&&url.pathname==='/api/apple'){send(200,store.apple(await body(req)));return;}
      if(req.method==='POST'&&url.pathname==='/api/claim'){const v=await body(req);closed(v,['requestId']);send(200,store.claim(v.requestId));return;}
      if(req.method==='POST'&&url.pathname==='/api/link'){send(200,store.link(await body(req)));return;}
      if(req.method==='GET'&&url.pathname.startsWith('/api/request/')){const r=store.request(decodeURIComponent(url.pathname.slice(13)));if(!r)fail('Request missing',404);send(200,r);return;}
      fail('Route missing',404);
    }catch(e){send(e.status||500,{error:e.status?e.message:'Internal error; request was not automatically retried'});}
  });
  server.requestTimeout=15000; server.headersTimeout=10000;
  server.on('close',()=>store.close()); return {server,store,config};
}
if(process.argv[1] && fileURLToPath(import.meta.url)===process.argv[1]) {
  process.umask(0o077);
  const {server}=createInboxServer(defaultDirectory(),{publicOrigin:process.env.THREAD_INBOX_PUBLIC_ORIGIN});
  server.listen(Number(process.env.THREAD_INBOX_PORT||48173),'127.0.0.1',()=>process.stderr.write('Thread Inbox is listening on loopback. Connection keys stay in the private connection file.\n'));
  const app=join(dirname(fileURLToPath(import.meta.url)),'Ideas Sources.app');
  if(process.platform==='darwin'&&existsSync(app))execFile('/usr/bin/open',['-g',app],{timeout:10000},()=>{});
  const stop=()=>server.close(()=>process.exit(0));process.on('SIGTERM',stop);process.on('SIGINT',stop);
}
