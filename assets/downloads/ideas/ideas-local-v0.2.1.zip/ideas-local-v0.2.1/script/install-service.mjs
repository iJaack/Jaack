import { mkdirSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

if(process.platform!=='darwin')throw Error('This installer is for macOS');
const root=fileURLToPath(new URL('..',import.meta.url));
const agentDirectory=join(homedir(),'Library/LaunchAgents');
const data=join(homedir(),'Library/Application Support/Thread Inbox');
mkdirSync(agentDirectory,{recursive:true});mkdirSync(data,{recursive:true,mode:0o700});
const escape=v=>String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
let environment='';
if(process.env.THREAD_INBOX_PUBLIC_ORIGIN){
  const origin=new URL(process.env.THREAD_INBOX_PUBLIC_ORIGIN);
  if(origin.protocol!=='https:'||origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash)throw Error('Public origin must be an HTTPS origin');
  environment=`<key>EnvironmentVariables</key><dict><key>THREAD_INBOX_PUBLIC_ORIGIN</key><string>${escape(origin.origin)}</string></dict>`;
}
const label='me.jaack.thread-inbox';
const plist=join(agentDirectory,label+'.plist');
writeFileSync(plist,`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>${label}</string>
<key>ProgramArguments</key><array><string>${escape(process.execPath)}</string><string>${escape(join(root,'service.mjs'))}</string></array>
<key>WorkingDirectory</key><string>${escape(root)}</string>
${environment}
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>Umask</key><integer>63</integer>
<key>StandardOutPath</key><string>${escape(join(data,'service.log'))}</string>
<key>StandardErrorPath</key><string>${escape(join(data,'service.log'))}</string>
</dict></plist>`,{mode:0o600});
const domain=`gui/${process.getuid()}`;
try{execFileSync('launchctl',['bootout',`${domain}/${label}`],{stdio:'ignore'});}catch{}
await new Promise(resolve=>setTimeout(resolve,500));
execFileSync('launchctl',['bootstrap',domain,plist],{stdio:'inherit'});
console.log('Installed Thread Inbox loopback service. Keys and SQLite remain in its private Application Support folder.');
