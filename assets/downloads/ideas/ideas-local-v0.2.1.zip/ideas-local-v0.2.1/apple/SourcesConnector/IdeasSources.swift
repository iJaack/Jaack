import SwiftUI
import EventKit

enum SharedInbox {
    static let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/Thread Inbox")
    static func call(_ path: String, body: Data? = nil) async throws -> Data {
        let keys = try JSONSerialization.jsonObject(with: Data(contentsOf: directory.appendingPathComponent("connection.json"))) as? [String: String]
        guard let token = keys?["adminToken"] else { throw URLError(.userAuthenticationRequired) }
        var request = URLRequest(url: URL(string: "http://127.0.0.1:48173" + path)!)
        request.timeoutInterval = 15
        request.httpMethod = body == nil ? "GET" : "POST"
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        return data
    }
}

@MainActor final class SourceModel: ObservableObject {
    @Published var message = "Connect this Mac to show your Calendar and Reminders in Ideas."
    @Published var busy = false
    private let sources = AppleSources()
    private var timer: Timer?
    private var lastRefresh = Date.distantPast
    private var handled = ""
    private var observer: NSObjectProtocol?
    private let statusURL = SharedInbox.directory.appendingPathComponent("apple-connector-status.json")
    init() {
        if let data = try? Data(contentsOf: statusURL), let status = try? JSONSerialization.jsonObject(with: data) as? [String: Any] { handled = status["requestId"] as? String ?? "" }
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in Task { @MainActor in await self?.pulse() } }
        observer = NotificationCenter.default.addObserver(forName: .EKEventStoreChanged, object: nil, queue: .main) { [weak self] _ in Task { @MainActor in self?.lastRefresh = .distantPast } }
        Task { await pulse() }
    }
    private func write(_ state: String, requestId: String = "", error: String? = nil) {
        var value: [String: Any] = ["state": state, "requestId": requestId.isEmpty ? handled : requestId, "updatedAt": ISO8601DateFormatter().string(from: Date())]
        if let error { value["error"] = error }
        do {
            let data = try JSONSerialization.data(withJSONObject: value)
            try data.write(to: statusURL, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: statusURL.path)
        } catch { message = "Could not record source status: \(error.localizedDescription)" }
    }
    func pulse() async {
        guard !busy else { return }
        let requestURL = SharedInbox.directory.appendingPathComponent("apple-request.json")
        if let data = try? Data(contentsOf: requestURL), let request = try? JSONSerialization.jsonObject(with: data) as? [String: String],
           let id = request["requestId"], id != handled, let stamp = request["createdAt"], let date = ISO8601DateFormatter().date(from: stamp), Date().timeIntervalSince(date) < 600 {
            handled = id
            await sync(connect: request["action"] == "connect")
        } else if Date().timeIntervalSince(lastRefresh) > 300 {
            await sync(connect: false)
        }
    }
    func sync(connect: Bool) async {
        guard !busy else { return }; busy = true; defer { busy = false }
        lastRefresh = Date()
        let initial = [EKEventStore.authorizationStatus(for: .event), EKEventStore.authorizationStatus(for: .reminder)]
        if !connect && initial.allSatisfy({ $0 == .notDetermined }) { write("disconnected"); return }
        write(connect ? "awaitingPermission" : "syncing")
        message = connect ? "Allow Calendar and Reminders access in the macOS dialogs." : "Reading local sources…"
        do {
            if connect { try await sources.connect() } else { try await sources.refresh() }
            let data = try await SharedInbox.call("/api/items?limit=1")
            let result = try JSONSerialization.jsonObject(with: data) as? [String: Any]
            let coverage = result?["sources"] as? [[String: Any]] ?? []
            let events = coverage.first { $0["kind"] as? String == "event" }
            let reminders = coverage.first { $0["kind"] as? String == "reminder" }
            let granted = [EKEventStore.authorizationStatus(for: .event), EKEventStore.authorizationStatus(for: .reminder)].allSatisfy { $0 == .fullAccess }
            message = "Calendar: \(events?["count"] as? Int ?? 0) events · Reminders: \(reminders?["count"] as? Int ?? 0) open items.\nLast read: \(Date().formatted(date: .omitted, time: .shortened))."
            if !granted { message += "\nAllow the missing permission in System Settings → Privacy & Security." }
            write(granted ? "connected" : "permissionNeeded")
        } catch { message = error.localizedDescription; write("failed", error: error.localizedDescription) }
    }
}

@main struct IdeasSourcesApp: App {
    @StateObject private var model = SourceModel()
    var body: some Scene {
        WindowGroup("Ideas · Mac sources") {
            VStack(alignment: .leading, spacing: 20) {
                Image(systemName: "calendar.badge.clock").font(.system(size: 32)).foregroundStyle(.green)
                Text("Your Mac, connected").font(.title2.weight(.semibold))
                Text("Ideas reads local Calendar events and incomplete Reminders. Your originals stay unchanged.").foregroundStyle(.secondary)
                Text(model.message).font(.callout).textSelection(.enabled)
                HStack {
                    Button("Connect Calendar & Reminders") { Task { await model.sync(connect: true) } }.buttonStyle(.borderedProminent)
                    Button("Refresh") { Task { await model.sync(connect: false) } }
                }.disabled(model.busy)
                Text("Refreshes every five minutes and when EventKit reports changes. Keep this local connector running.").font(.caption).foregroundStyle(.secondary)
            }.padding(28).frame(width: 460)
        }.windowResizability(.contentSize)
    }
}
