import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { once } from 'node:events';
import { Store } from '../store.mjs';
import { createInboxServer } from '../service.mjs';

const temp = () => mkdtempSync(join(tmpdir(),'thread-inbox-test-'));
function fixture(t) { const dir=temp(); const store=new Store(dir);t.after(()=>{store.close();rmSync(dir,{recursive:true,force:true});});return store; }
const note=()=>({requestId:randomUUID(),body:'Explore a shared browser idea',title:'A useful idea',url:'https://example.com/article',device:'test'});
function apple(kind, items, checkedAt=new Date().toISOString()) {return{kind,status:'available',checkedAt,windowStart:new Date(Date.now()-86400000).toISOString(),windowEnd:new Date(Date.now()+7*86400000).toISOString(),items};}
const event=(sourceId,startAt)=>({sourceId,title:'Planning call',body:'Agenda notes',calendar:'Work',startAt,endAt:new Date(Date.parse(startAt)+3600000).toISOString(),allDay:false});

test('capture survives reopen; retries preserve identity and conflicting retries fail',t=>{
  const dir=temp();let store=new Store(dir);t.after(()=>{store.close();rmSync(dir,{recursive:true,force:true});});
  const input=note(),saved=store.idea(input);assert.equal(store.idea(input).id,saved.id);assert.equal(store.list('idea').total,1);
  assert.throws(()=>store.idea({...input,body:'Changed'}),/different content/);
  store.close();store=new Store(dir);assert.equal(store.get(saved.id).body,input.body);assert.equal(store.db.prepare('SELECT count(*) AS n FROM requests').get().n,0);
});
test('source keys distinguish recurring event occurrences and preserve repeated titles',t=>{
  const s=fixture(t),a=new Date().toISOString(),b=new Date(Date.now()+86400000).toISOString();
  s.apple(apple('event',[event('same-series',a),event('same-series',b),event('other-series',a)]));assert.equal(s.list('event').total,3);
  const id=s.list('event').items[0].id;s.apple(apple('event',[event('same-series',a)]));assert.equal(s.list('event').total,1);assert(s.get(id));
});
test('invalid or duplicate Apple batch leaves the existing snapshot intact',t=>{
  const s=fixture(t),e=event('one',new Date().toISOString());s.apple(apple('event',[e]));
  assert.throws(()=>s.apple(apple('event',[e,e])),/Duplicate/);assert.equal(s.list('event').total,1);
  assert.throws(()=>s.apple(apple('event',[{...e,startAt:'invalid'}])),/Invalid/);assert.equal(s.list('event').total,1);
});
test('unavailable sources are labelled and cannot dispatch retained stale items',t=>{
  const s=fixture(t),e=event('one',new Date().toISOString());s.apple(apple('event',[e]));const id=s.list('event').items[0].id;
  s.apple({...apple('event',[]),status:'denied'});assert.equal(s.list('event').sources[0].status,'denied');assert.equal(s.list('event').total,0);assert.throws(()=>s.prepare({itemId:id}),/missing/);
});
test('a selected idea prepares exactly one request and never dispatches from capture',t=>{
  const s=fixture(t),item=s.idea(note());assert.equal(s.db.prepare('SELECT count(*) AS n FROM requests').get().n,0);
  const r=s.prepare({itemId:item.id});assert.equal(r.status,'prepared');assert.equal(s.prepare({itemId:item.id}).id,r.id);assert.match(r.prompt,/SOURCE RECORD/);
  assert.equal(s.claim(r.id).claimed,true);assert.equal(s.claim(r.id).claimed,false);assert.equal(s.prepare({itemId:item.id}).status,'dispatching');
});
test('Apple refresh with identical content preserves claim; substantive changes block it',t=>{
  const s=fixture(t),e=event('one',new Date().toISOString());s.apple(apple('event',[e]));const id=s.list('event').items[0].id,r=s.prepare({itemId:id});
  s.apple(apple('event',[Object.fromEntries(Object.entries(e).reverse())],new Date(Date.now()+1000).toISOString()));assert.equal(s.claim(r.id).claimed,true);
  const e2=event('two',new Date().toISOString());s.apple(apple('event',[e2]));const r2=s.prepare({itemId:s.list('event').items[0].id});
  s.apple(apple('event',[{...e2,body:'New details'}]));assert.throws(()=>s.claim(r2.id),/Source changed/);
});
test('stale Apple snapshots cannot create a chat',t=>{
  const s=fixture(t),e=event('one',new Date().toISOString());s.apple(apple('event',[e]));const id=s.list('event').items[0].id;
  const old={...s.get(id),checkedAt:new Date(Date.now()-16*60000).toISOString()};s.db.prepare('UPDATE items SET body=? WHERE id=?').run(JSON.stringify(old),id);
  assert.throws(()=>s.prepare({itemId:id}),/stale/);
});
test('native links require a claim, retain exact provider identity, and reject replacement',t=>{
  const s=fixture(t),i=s.idea(note()),r=s.prepare({itemId:i.id}),threadId=randomUUID();
  assert.throws(()=>s.link({requestId:r.id,threadId,hostId:'local'}),/Claim/);s.claim(r.id);
  s.link({requestId:r.id,threadId,hostId:'local'});assert.equal(s.request(r.id).threadId,threadId);assert.equal(s.prepare({itemId:i.id}).threadId,threadId);
  assert.throws(()=>s.link({requestId:r.id,threadId:randomUUID(),hostId:'local'}),/already linked/);
});
test('HTTP receiver refuses unauthorized/cross-origin requests and isolates device authority',async t=>{
  const dir=temp(),{server,config}=createInboxServer(dir,{publicOrigin:'https://private.example:5443'});server.listen(0,'127.0.0.1');await once(server,'listening');
  t.after(async()=>{await new Promise(r=>server.close(r));rmSync(dir,{recursive:true,force:true});});
  const origin=`http://127.0.0.1:${server.address().port}`;
  assert.equal((await fetch(origin+'/api/items')).status,401);
  const headers={Authorization:`Bearer ${config.captureToken}`,'Content-Type':'application/json'};
  assert.equal((await fetch(origin+'/api/items',{headers:{...headers,Origin:origin}})).status,200);
  assert.equal((await fetch(origin+'/api/items',{headers:{...headers,Origin:'https://private.example:5443'}})).status,200);
  assert.equal((await fetch(origin+'/api/items',{headers:{...headers,Origin:'https://evil.example'}})).status,403);
  assert.equal((await fetch(origin+'/api/apple',{method:'POST',headers,body:JSON.stringify(apple('event',[]))})).status,403);
  assert.equal((await fetch(origin+'/api/apple/sync',{method:'POST',headers,body:JSON.stringify({action:'connect'})})).status,403);
  const input=note(),saved=await(await fetch(origin+'/api/ideas',{method:'POST',headers,body:JSON.stringify(input)})).json();assert.equal(saved.status,'verified');
  const readback=await(await fetch(origin+'/api/item/'+encodeURIComponent(saved.record.id),{headers})).json();assert.equal(readback.body,input.body);
  assert.equal((await fetch(origin+'/api/ideas',{method:'POST',headers,body:JSON.stringify({...input,bogus:true})})).status,400);
});
test('packaged MCP discovery, tool validation, capture and claim work through real stdio',async t=>{
  const dir=temp(),{server,config}=createInboxServer(dir);server.listen(0,'127.0.0.1');await once(server,'listening');
  const imported=await fetch(`http://127.0.0.1:${server.address().port}/api/apple`,{method:'POST',headers:{Authorization:`Bearer ${config.adminToken}`,'Content-Type':'application/json'},body:JSON.stringify(apple('event',[event('test-calendar',new Date().toISOString())]))});assert.equal(imported.status,200);
  const launch=JSON.parse(readFileSync(new URL('../plugin/.mcp.json',import.meta.url))).mcpServers['thread-inbox'];
  const child=spawn(launch.command,launch.args,{cwd:new URL('../plugin/'+launch.cwd+'/',import.meta.url),env:{...process.env,PATH:'/usr/bin:/bin:/usr/sbin:/sbin',THREAD_INBOX_DATA:dir,THREAD_INBOX_API_URL:`http://127.0.0.1:${server.address().port}`},stdio:['pipe','pipe','pipe']});
  const pending=new Map();let id=0;createInterface({input:child.stdout}).on('line',line=>{const v=JSON.parse(line);const p=pending.get(v.id);if(p){pending.delete(v.id);p.resolve(v);}});
  let errors='';child.stderr.on('data',d=>errors+=d);child.on('exit',()=>{for(const p of pending.values())p.reject(Error('MCP exited: '+errors));});
  const call=(method,params)=>new Promise((resolve,reject)=>{const key=++id;const timer=setTimeout(()=>reject(Error('MCP timeout')),5000);pending.set(key,{resolve:v=>{clearTimeout(timer);resolve(v);},reject:e=>{clearTimeout(timer);reject(e);}});child.stdin.write(JSON.stringify({jsonrpc:'2.0',id:key,method,params})+'\n');});
  t.after(async()=>{child.kill();await new Promise(r=>server.close(r));rmSync(dir,{recursive:true,force:true});});
  assert((await call('initialize',{})).result.capabilities.tools);const list=(await call('tools/list')).result;assert.equal(list.tools.length,8);
  const entry=list.tools.find(t=>t.name==='inbox');assert.equal(entry.title,'Ideas');assert.deepEqual(entry._meta['openai/ui'].entrypoints,[{type:'global'}]);
  const input=note();const saved=(await call('tools/call',{name:'capture_idea',arguments:input})).result;assert(!saved.isError);
  assert.equal((await call('tools/call',{name:'inbox',arguments:{kind:'event'}})).result.structuredContent.total,1);
  assert.equal((await call('tools/call',{name:'inbox',arguments:{kind:'all'}})).result.structuredContent.total,2);
  const inbox=(await call('tools/call',{name:'inbox',arguments:{}})).result.structuredContent;assert.equal(inbox.total,1);assert.equal(inbox.kind,'idea');assert(inbox.items.every(i=>i.kind==='idea'));
  const invalid=(await call('tools/call',{name:'inbox',arguments:{limit:0}})).result;assert(invalid.isError);
  const resource=(await call('resources/read',{uri:'ui://thread-inbox/inbox.html'})).result;assert.match(resource.contents[0].text,/Create chat/);assert.match(resource.contents[0].text,/Framework-free MCP App styles/);assert.match(resource.contents[0].text,/host-context-changed/);assert(!resource.contents[0].text.includes('/* CODEX_STYLES */'));assert.equal(resource.contents[0]._meta['openai/ui'].preferredDisplayMode,'fullscreen');
});

test('search and pagination keep source counts and return every matching item once',t=>{
  const s=fixture(t);for(let n=0;n<62;n++)s.idea({...note(),title:`Saved thought ${n}`,body:n%2?'Design idea':'Calendar question'});
  const first=s.list('idea',50),second=s.list('idea',50,first.nextOffset);assert.equal(first.counts.idea,62);assert.equal(second.items.length,12);assert.equal(second.nextOffset,null);assert.equal(new Set([...first.items,...second.items].map(i=>i.id)).size,62);
  const filtered=s.list('idea',10,0,'DESIGN');assert.equal(filtered.total,31);assert.equal(filtered.counts.idea,62);assert.equal(filtered.nextOffset,10);assert(filtered.items.every(i=>i.preview.includes('Design')));assert.throws(()=>s.list('idea',50,-1),/Invalid/);
});

test('remote MCP serves the same Ideas page and data while refusing device capture tokens',async t=>{
  const dir=temp(),{server,store,config}=createInboxServer(dir);server.listen(0,'127.0.0.1');await once(server,'listening');t.after(async()=>{await new Promise(r=>server.close(r));rmSync(dir,{recursive:true,force:true});});
  store.idea(note());const origin=`http://127.0.0.1:${server.address().port}`,headers={Authorization:`Bearer ${config.adminToken}`,'Content-Type':'application/json'};
  const invoke=async(method,params)=>{const r=await fetch(origin+'/mcp',{method:'POST',headers,body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});assert.equal(r.status,200);return r.json();};
  const init=await invoke('initialize',{protocolVersion:'2025-03-26'});assert.equal(init.result.protocolVersion,'2025-03-26');
  const list=await invoke('tools/list',{});assert.equal(list.result.tools.length,8);assert.deepEqual(list.result.tools[0]._meta['openai/ui'].entrypoints,[{type:'global'}]);
  const data=await invoke('tools/call',{name:'inbox',arguments:{}});assert.equal(data.result.structuredContent.total,1);
  const ui=await invoke('resources/read',{uri:'ui://thread-inbox/inbox.html'});assert.match(ui.result.contents[0].text,/Framework-free MCP App styles/);
  assert.equal((await fetch(origin+'/mcp',{method:'POST',headers:{...headers,Authorization:`Bearer ${config.captureToken}`},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/list'})})).status,403);
  assert.equal((await fetch(origin+'/mcp',{headers})).status,405);
  assert.equal((await fetch(origin+'/mcp',{method:'POST',headers,body:JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})})).status,204);
});
