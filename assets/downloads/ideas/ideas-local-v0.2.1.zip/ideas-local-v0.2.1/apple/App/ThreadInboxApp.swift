import SwiftUI
#if os(macOS)
import AppKit
#else
import UIKit
#endif

struct InboxItem: Decodable, Identifiable {
    let id: String
    let title: String
    let kind: String
    let preview: String
}
struct InboxResult: Decodable { let items: [InboxItem]; let total: Int; let truncated: Bool }

@MainActor final class InboxModel: ObservableObject {
    @Published var items: [InboxItem] = []
    @Published var status = "Pair this device to your inbox."
    @Published var busy = false
    @Published var queued = 0
    @Published var request = ""
    @Published var showingRequest = false
    private let sources = AppleSources()
    func refresh() async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do {
            let ideas = try SharedInbox.queued(); queued = ideas.count
            for idea in ideas { try await SharedInbox.send(idea); queued -= 1 }
            #if os(macOS)
            try await sources.refresh()
            #endif
            let data = try await SharedInbox.call("/api/items?limit=100")
            let result = try JSONDecoder().decode(InboxResult.self, from: data)
            items = result.items
            status = "Showing \(items.count) of \(result.total) items. \(queued) ideas queued on this device."
        } catch { status = error.localizedDescription }
    }
    func connectApple() async {
        guard !busy else { return }; busy = true
        do { try await sources.connect(); status = "Apple sources imported." } catch { status = error.localizedDescription }
        busy = false; await refresh()
    }
    func save(_ body: String) async -> Bool {
        do { try SharedInbox.queue(Idea(body: body)); queued += 1; await refresh(); return true }
        catch { status = error.localizedDescription; return false }
    }
    func prepare(_ item: InboxItem) async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do {
            let data = try await SharedInbox.call("/api/chat-requests", body: JSONSerialization.data(withJSONObject: ["itemId": item.id]))
            guard let value = try JSONSerialization.jsonObject(with: data) as? [String: Any], let id = value["id"] as? String else { throw InboxError.server("Chat request was not prepared.") }
            request = "Use Thread Inbox $create-chat for request \(id). I selected Create chat for item \(item.id). Create the native Codex chat, or open its verified existing link."
            showingRequest = true
        } catch { status = error.localizedDescription }
    }
    func pairMac() {
        #if os(macOS)
        do {
            let file = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/Thread Inbox/connection.json")
            guard let value = try JSONSerialization.jsonObject(with: Data(contentsOf: file)) as? [String: String], let token = value["adminToken"] else { throw InboxError.missingPairing }
            SharedInbox.defaults.set("http://127.0.0.1:48173", forKey: "address")
            SharedInbox.defaults.set(token, forKey: "token")
            status = "Mac paired. Refresh or connect Apple sources."
        } catch { status = error.localizedDescription }
        #endif
    }
}

@main struct ThreadInboxApp: App {
    @StateObject private var model = InboxModel()
    var body: some Scene {
        WindowGroup { InboxView(model: model) }
    }
}

struct InboxView: View {
    @ObservedObject var model: InboxModel
    @State private var address = SharedInbox.defaults.string(forKey: "address") ?? ""
    @State private var token = ""
    @State private var idea = ""
    @Environment(\.scenePhase) private var phase
    var body: some View {
        NavigationStack {
            List {
                Section("Connection") {
                    TextField("Inbox HTTPS address", text: $address)
                    SecureField("Device connection token", text: $token)
                    Button("Save connection") {
                        SharedInbox.defaults.set(address, forKey: "address")
                        if !token.isEmpty { SharedInbox.defaults.set(token, forKey: "token"); token = "" }
                        Task { await model.refresh() }
                    }
                    #if os(macOS)
                    Button("Pair this Mac") { model.pairMac(); address = SharedInbox.defaults.string(forKey: "address") ?? "" }
                    Button("Connect Apple Calendar and Reminders") { Task { await model.connectApple() } }
                    #endif
                }
                Section("New idea") {
                    TextEditor(text: $idea).frame(minHeight: 80).accessibilityLabel("Idea")
                    Button("Save idea") { let note = idea; Task { if await model.save(note) { idea = "" } } }.disabled(idea.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || model.busy)
                }
                Section("Inbox") {
                    ForEach(model.items) { item in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(item.title).font(.headline)
                            Text(item.kind.capitalized).font(.caption).foregroundStyle(.secondary)
                            if !item.preview.isEmpty { Text(item.preview).font(.callout).foregroundStyle(.secondary) }
                            Button("Prepare chat") { Task { await model.prepare(item) } }.disabled(model.busy)
                        }.padding(.vertical, 6)
                    }
                }
                Section { Text(model.status).font(.callout).foregroundStyle(.secondary) }
            }
            .navigationTitle("Thread Inbox")
            .toolbar { Button("Refresh") { Task { await model.refresh() } }.disabled(model.busy) }
            .sheet(isPresented: $model.showingRequest) {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Continue in Codex").font(.title2)
                    Text("Paste this request into Codex. The plugin creates the native chat and keeps its source link.")
                    TextEditor(text: $model.request).frame(minHeight: 100).accessibilityLabel("Codex request")
                    HStack {
                        Button("Copy request") {
                            #if os(macOS)
                            NSPasteboard.general.clearContents(); NSPasteboard.general.setString(model.request, forType: .string)
                            #else
                            UIPasteboard.general.string = model.request
                            #endif
                        }
                        Button("Close") { model.showingRequest = false }
                    }
                }.padding(24).frame(minWidth: 300, minHeight: 260)
            }
            .onChange(of: phase) { _, value in if value == .active { Task { await model.refresh() } } }
        }
        #if os(macOS)
        .frame(minWidth: 480, minHeight: 640)
        #endif
    }
}
