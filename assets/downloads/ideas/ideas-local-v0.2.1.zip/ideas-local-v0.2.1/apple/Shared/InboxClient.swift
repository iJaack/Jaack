import Foundation

enum InboxError: LocalizedError {
    case invalidAddress, missingPairing, unavailableGroup, server(String)
    var errorDescription: String? {
        switch self {
        case .invalidAddress: return "Use an HTTPS inbox address. The Mac can use http://127.0.0.1:48173 for local development."
        case .missingPairing: return "Pair this device with your independent inbox first."
        case .unavailableGroup: return "The shared container is unavailable. Install a signed app and Share extension with the same App Group."
        case .server(let message): return message
        }
    }
}

struct Idea: Codable, Identifiable {
    let requestId: String
    var body: String
    var title: String
    var url: String
    var device: String
    var id: String { requestId }
    init(body: String, url: String = "") {
        requestId = UUID().uuidString.lowercased()
        self.body = body
        title = String((body.split(separator: "\n").first.map(String.init) ?? "Idea").prefix(100))
        self.url = url
        #if os(macOS)
        device = "mac"
        #else
        device = "ios"
        #endif
    }
}

enum SharedInbox {
    static let group = "group.me.jaack.thread-inbox"
    static var defaults: UserDefaults { UserDefaults(suiteName: group) ?? .standard }
    static func directory() throws -> URL {
        guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else { throw InboxError.unavailableGroup }
        let directory = container.appendingPathComponent("outbox", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        return directory
    }
    static func queue(_ idea: Idea) throws {
        let file = try directory().appendingPathComponent(idea.id + ".json")
        try JSONEncoder().encode(idea).write(to: file, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: file.path)
    }
    static func queued() throws -> [Idea] {
        try FileManager.default.contentsOfDirectory(at: directory(), includingPropertiesForKeys: nil)
            .filter { $0.pathExtension == "json" }.sorted { $0.path < $1.path }
            .map { try JSONDecoder().decode(Idea.self, from: Data(contentsOf: $0)) }
    }
    static func remove(_ idea: Idea) throws {
        do { try FileManager.default.removeItem(at: directory().appendingPathComponent(idea.id + ".json")) }
        catch let error as CocoaError where error.code == .fileNoSuchFile { }
    }
    static func origin() throws -> URL {
        guard let raw = defaults.string(forKey: "address"), let url = URL(string: raw),
              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil,
              url.path.isEmpty || url.path == "/" else { throw InboxError.invalidAddress }
        #if os(macOS)
        let local = url.scheme == "http" && url.host == "127.0.0.1"
        #else
        let local = false
        #endif
        guard url.host != nil, url.scheme == "https" || local else { throw InboxError.invalidAddress }
        return url
    }
    static func call(_ path: String, body: Data? = nil) async throws -> Data {
        let origin = try origin()
        guard let token = defaults.string(forKey: "token"), token.count == 64 else { throw InboxError.missingPairing }
        guard let url = URL(string: path, relativeTo: origin) else { throw InboxError.invalidAddress }
        var request = URLRequest(url: url, timeoutInterval: 10)
        request.httpMethod = body == nil ? "GET" : "POST"
        request.httpBody = body
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let session = URLSession(configuration: .ephemeral, delegate: NoRedirects(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        let (data, response) = try await session.data(for: request)
        guard let response = response as? HTTPURLResponse, (200..<300).contains(response.statusCode) else {
            let error = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            throw InboxError.server(error?["error"] as? String ?? "Inbox did not confirm the request. Keep its original ID.")
        }
        return data
    }
    static func send(_ idea: Idea) async throws {
        let data = try await call("/api/ideas", body: JSONEncoder().encode(idea))
        guard let result = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let record = result["record"] as? [String: Any], let id = record["id"] as? String else { throw InboxError.server("Save was not verified.") }
        let readback = try await call("/api/item/" + id)
        guard let saved = try JSONSerialization.jsonObject(with: readback) as? [String: Any],
              saved["body"] as? String == idea.body, saved["title"] as? String == idea.title,
              saved["url"] as? String == idea.url, saved["device"] as? String == idea.device else {
            throw InboxError.server("Readback differs from the original note. It remains queued.")
        }
        try remove(idea)
    }
}

final class NoRedirects: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}
