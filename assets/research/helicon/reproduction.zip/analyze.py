"""Analyze monthly historical snapshots without filling pre-launch observations."""
from pathlib import Path
from datetime import date
import json,csv,math,statistics,hashlib
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
CAPS={'BTC':21e6,'AVAX':720e6,'ADA':45e9,'SUI':10e9}
UNCAPPED=['ETH','SOL','ATOM','NEAR']
CHECKS=[]


def check(name,ok):
    CHECKS.append({'check':name,'passed':bool(ok)})
    assert ok,name


def corr(x,y):
    if len(x)<3 or np.ptp(x)==0 or np.ptp(y)==0:return None
    return float(np.corrcoef(x,y)[0,1])


def dump(name,rows):
    if name.endswith('.csv'):pd.DataFrame(rows).to_csv(ROOT/name,index=False)
    else:(ROOT/name).write_text(json.dumps(rows,indent=2,allow_nan=False))


def main():
    rows=json.loads((ROOT/'snapshots.json').read_text())
    months=sorted({r['month'] for r in rows})
    check('81 contiguous monthly snapshots',len(months)==81 and months[0]=='2020-01' and months[-1]=='2026-09')
    check('705 unique token/month rows',len(rows)==len({(r['token'],r['month']) for r in rows})==705)
    by={(r['token'],r['month']):r for r in rows}
    tokens=list(dict.fromkeys(r['token'] for r in rows))
    profiles=[]
    for t in tokens:
        data=[r for r in rows if r['token']==t]
        check(t+': complete observed monthly history',[r['month'] for r in data]==months[months.index(data[0]['month']):])
        gaps=[]
        for r in data:
            check(f"{t} {r['month']}: positive finite price",math.isfinite(r['price_usd']) and r['price_usd']>0)
            if r['circulating'] is None:
                check(f"{t} {r['month']}: explicit missing supply",t=='SOL' and r['month'] in ['2020-05','2020-06','2020-07','2020-08'] and r['market_cap_usd']==0)
            else:
                check(f"{t} {r['month']}: positive supply and market cap",all(math.isfinite(r[k]) and r[k]>0 for k in ['circulating','market_cap_usd']))
                gaps.append(abs(r['price_usd']*r['circulating']/r['market_cap_usd']-1))
            r['policy_ceiling']=CAPS.get(t)
            r['ratio']=r['circulating']/CAPS[t] if t in CAPS else None
        profiles.append({'token':t,'rows':len(data),'first':data[0]['date'],'last':data[-1]['date'],
                         'first_supply_date':next(r['date'] for r in data if r['circulating'] is not None),
                         'missing_supply_rows':sum(r['circulating'] is None for r in data),'max_market_cap_identity_gap':max(gaps)})
    check('APT has no fabricated pre-launch rows',by.get(('APT','2021-01')) is None and ('APT','2022-11') in by)
    check('SUI has no fabricated pre-launch rows',by.get(('SUI','2021-01')) is None and ('SUI','2023-05') in by)
    dump('monthly-snapshots.csv',rows)
    summary=[]
    for t in ['BTC','ETH','AVAX','SOL','APT','SUI','ADA','DOT','ATOM','NEAR']:
        data=[r for r in rows if r['token']==t];a,b=data[0],data[-1]
        summary.append({'token':t,'start_date':a['date'],'end_date':b['date'],
                        'start_price':a['price_usd'],'end_price':b['price_usd'],
                        'start_circulating':a['circulating'],'end_circulating':b['circulating'],
                        'start_ratio':a['ratio'],'end_ratio':b['ratio'],
                        'first_supply_date':next(r['date'] for r in data if r['circulating'] is not None),
                        'first_reported_circulating':next(r['circulating'] for r in data if r['circulating'] is not None),
                        'price_return':b['price_usd']/a['price_usd']-1,
                        'common_start_date':by[t,'2023-05']['date'],
                        'return_since_common_may_2023':b['price_usd']/by[t,'2023-05']['price_usd']-1,
                        'circulation_growth':b['circulating']/a['circulating']-1 if a['circulating'] is not None else None})
    dump('long-horizon.csv',summary)
    annual=[];cross=[];cohorts=[]
    periods=[(str(y),f'{y}-01',f'{y+1}-01') for y in range(2020,2026)]+[('2026 partial','2026-01','2026-09')]
    for label,start,end in periods:
        available=[t for t in tokens if (t,start) in by and (t,end) in by]
        for t in available:
            a,b=by[t,start],by[t,end]
            annual.append({'period':label,'token':t,'start':a['date'],'end':b['date'],'start_ratio':a['ratio'],'end_ratio':b['ratio'],
                           'price_return':b['price_usd']/a['price_usd']-1,'circulation_growth':b['circulating']/a['circulating']-1})
        slice=[r for r in annual if r['period']==label]
        capped=[r for r in slice if r['token'] in CAPS]
        cross.append({'period':label,'n':len(capped),'tokens':','.join(r['token'] for r in capped),
                       'start_ratio_return_pearson':corr([r['start_ratio'] for r in capped],[r['price_return'] for r in capped]),
                       'end_ratio_return_pearson':corr([r['end_ratio'] for r in capped],[r['price_return'] for r in capped]),
                       'all_available_n':len(slice),'circulation_growth_return_pearson':corr([r['circulation_growth'] for r in slice],[r['price_return'] for r in slice])})
        for group,names in [('Capped: BTC, AVAX, ADA',['BTC','AVAX','ADA']),('Uncapped: ETH, SOL, ATOM, NEAR',UNCAPPED),('Uncapped excluding SOL',['ETH','ATOM','NEAR']),('2020 available capped: BTC, ADA',['BTC','ADA']),('2020 available uncapped: ETH, ATOM',['ETH','ATOM'])]:
            vals=[r['price_return'] for r in slice if r['token'] in names]
            if len(vals)!=len(names):continue
            cohorts.append({'period':label,'group':group,'n':len(vals),'mean_return':statistics.mean(vals),'median_return':statistics.median(vals)})
    dump('annual-returns.csv',annual);dump('annual-correlations.csv',cross);dump('cohort-returns.csv',cohorts)
    panels=[];panel_results=[]
    for cohort,names,first in [('2020 pair',['BTC','ADA'],'2020-01'),('AVAX-era core',['BTC','AVAX','ADA'],'2020-10'),('AVAX-era core ex BTC',['AVAX','ADA'],'2020-10'),('2021 core',['BTC','AVAX','ADA'],'2021-01'),('2021 core ex BTC',['AVAX','ADA'],'2021-01'),('SUI-era core',['BTC','AVAX','ADA','SUI'],'2023-05'),('SUI-era core ex BTC',['AVAX','ADA','SUI'],'2023-05')]:
        for horizon in [3,12]:
            data=[]
            for i,m in enumerate(months):
                if m<first or i+horizon>=len(months):continue
                finish=months[i+horizon]
                for t in names:
                    a,b=by[t,m],by[t,finish]
                    data.append({'cohort':cohort,'horizon_months':horizon,'token':t,'start':a['date'],'end':b['date'],'start_month':m,
                                  'ratio':a['ratio'],'forward_log_return':math.log(b['price_usd']/a['price_usd'])})
            pdf=pd.DataFrame(data)
            residuals=[]
            for col in ['ratio','forward_log_return']:
                residuals.append((pdf[col]-pdf.groupby('token')[col].transform('mean')-pdf.groupby('start_month')[col].transform('mean')+pdf[col].mean()).to_numpy())
            panels.extend(data)
            panel_results.append({'cohort':cohort,'tokens':len(names),'horizon_months':horizon,'rows':len(data),'start_windows':len(data)//len(names),
                                  'first_start':data[0]['start'],'last_start':data[-1]['start'],
                                  'demeaned_pearson':corr(*residuals)})
            offsets=[]
            starts=sorted(pdf.start_month.unique())
            for offset in range(horizon):
                sub=pdf[pdf.start_month.isin(starts[offset::horizon])]
                if sub.start_month.nunique()<2:continue
                residual=[]
                for col in ['ratio','forward_log_return']:
                    residual.append((sub[col]-sub.groupby('token')[col].transform('mean')-sub.groupby('start_month')[col].transform('mean')+sub[col].mean()).to_numpy())
                offsets.append({'offset':offset,'rows':len(sub),'coefficient':corr(*residual)})
            panel_results[-1]['nonoverlapping_offset_min']=min(r['coefficient'] for r in offsets)
            panel_results[-1]['nonoverlapping_offset_max']=max(r['coefficient'] for r in offsets)
    dump('forward-panel.csv',panels);dump('panel-results.csv',panel_results)
    full_cross=[]
    for start,names in [('2020-01',['BTC','ADA']),('2020-10',['BTC','AVAX','ADA']),('2021-01',['BTC','AVAX','ADA']),('2022-01',['BTC','AVAX','ADA']),('2023-05',['BTC','AVAX','ADA','SUI']),('2023-05',['AVAX','ADA','SUI'])]:
        x=[by[t,start]['ratio'] for t in names];y=[by[t,months[-1]]['price_usd']/by[t,start]['price_usd']-1 for t in names]
        full_cross.append({'start':start,'end':months[-1],'tokens':','.join(names),'n':len(names),'start_ratio_return_pearson':corr(x,y),
                           'end_ratio_return_pearson':corr([by[t,months[-1]]['ratio'] for t in names],y)})
    changes=[]
    for t in tokens:
        data=[r for r in rows if r['token']==t]
        for a,b in zip(data,data[1:]):
            if a['circulating'] is None or b['circulating'] is None:continue
            change=b['circulating']/a['circulating']-1
            if abs(change)>.10:changes.append({'token':t,'start':a['date'],'end':b['date'],'circulation_change':change})
    thresholds=[]
    for t in CAPS:
        data=[r for r in rows if r['token']==t]
        for threshold in [.9,.95,.99]:
            crossed=next((b['date'] for a,b in zip(data,data[1:]) if a['ratio']<threshold<=b['ratio']),None)
            thresholds.append({'token':t,'threshold':threshold,'first_observed_upward_crossing':crossed,
                               'start_ratio':data[0]['ratio'],'end_ratio':data[-1]['ratio']})
    avax_anchors=[r for r in rows if r['token']=='AVAX' and (r['month'].endswith('-01') or r['month'] in ['2020-10','2026-09'])]
    result={'coverage':profiles,'long_horizon':summary,'annual_correlations':cross,'annual_cohorts':cohorts,'panel_results':panel_results,
             'long_horizon_correlations':full_cross,'large_monthly_supply_changes':changes,'thresholds':thresholds,'avax_anchors':avax_anchors}
    dump('analysis.json',result)
    dump('validation.json',{'status':'passed','count':len(CHECKS),'checks':CHECKS})
    print(json.dumps({k:result[k] for k in ['long_horizon_correlations','annual_correlations','panel_results','thresholds']},indent=2))


if __name__=='__main__':main()
