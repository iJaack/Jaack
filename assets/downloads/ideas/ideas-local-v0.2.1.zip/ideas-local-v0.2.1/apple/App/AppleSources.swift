import EventKit
import Foundation

@MainActor final class AppleSources {
    private let store = EKEventStore()
    private let formatter = ISO8601DateFormatter()
    func connect() async throws {
        let calendar = try await store.requestFullAccessToEvents()
        let reminders = try await store.requestFullAccessToReminders()
        try await upload(calendar: calendar, reminders: reminders)
    }
    func refresh() async throws {
        try await upload(calendar: EKEventStore.authorizationStatus(for: .event) == .fullAccess,
                         reminders: EKEventStore.authorizationStatus(for: .reminder) == .fullAccess)
    }
    private func upload(calendar: Bool, reminders: Bool) async throws {
        let now = Date(), end = now.addingTimeInterval(7 * 24 * 3600)
        let start = now.addingTimeInterval(-24 * 3600)
        let checked = formatter.string(from: now)
        let events: [[String: Any]] = calendar ? store.events(matching: store.predicateForEvents(withStart: start, end: end, calendars: nil)).map { event in
            let item: [String: Any] = ["sourceId": event.calendarItemIdentifier, "title": event.title ?? "Untitled event",
                "body": event.notes ?? "", "calendar": event.calendar.title, "startAt": formatter.string(from: event.startDate),
                "endAt": formatter.string(from: event.endDate), "allDay": event.isAllDay, "location": event.location ?? "", "url": event.url?.absoluteString ?? ""]
            return item
        } : []
        let eventSnapshot: [String: Any] = ["kind": "event", "status": calendar ? "available" : "denied", "checkedAt": checked,
            "windowStart": formatter.string(from: start), "windowEnd": formatter.string(from: end), "items": events]
        _ = try await SharedInbox.call("/api/apple", body: JSONSerialization.data(withJSONObject: eventSnapshot))
        let fetched: [EKReminder] = reminders ? await withCheckedContinuation { continuation in
            store.fetchReminders(matching: store.predicateForIncompleteReminders(withDueDateStarting: nil, ending: nil, calendars: nil)) { values in
                continuation.resume(returning: values ?? [])
            }
        } : []
        let items: [[String: Any]] = fetched.map { reminder in
            var item: [String: Any] = ["sourceId": reminder.calendarItemIdentifier, "title": reminder.title ?? "Untitled reminder",
                "body": reminder.notes ?? "", "calendar": reminder.calendar.title, "url": reminder.url?.absoluteString ?? ""]
            if let components = reminder.dueDateComponents, let due = (components.calendar ?? Calendar.current).date(from: components) {
                item["dueAt"] = formatter.string(from: due)
                item["allDay"] = components.hour == nil
            }
            return item
        }
        _ = try await SharedInbox.call("/api/apple", body: JSONSerialization.data(withJSONObject: ["kind": "reminder", "status": reminders ? "available" : "denied", "checkedAt": formatter.string(from: Date()), "items": items]))
    }
}
