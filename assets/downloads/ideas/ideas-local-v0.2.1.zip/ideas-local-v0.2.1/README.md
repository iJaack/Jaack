# Ideas for Codex — local source preview v0.2.1

An independent, private inbox for shared thoughts, local Apple Calendar events, and open Reminders. Uses OpenAI MCP App styles and inherits host light/dark theme tokens. Only choosing Create chat prepares a native Codex chat request; source records are never modified.

## Run on your Mac

Requires macOS 14+, Xcode, XcodeGen and Node 22.13+.

```sh
./script/build-sources.sh
node script/install-service.mjs
codex plugin marketplace add "$PWD"
codex plugin add thread-inbox@thread-inbox-local
```

Open Ideas in Codex, select Connect Mac sources, and allow Calendar and Reminders in the macOS dialogs. The separate Ideas Sources application uses EventKit to import yesterday through the next seven days of Calendar events, and all incomplete reminders. It refreshes every five minutes and when EventKit reports changes. macOS full-access grants are required; this connector only reads. The locally built app is ad-hoc signed and not notarized.

The service binds only 127.0.0.1:48173. SQLite and connection tokens stay in the owner's private Application Support folder. The owner token permits plugin operations; the restricted device token permits capture, read and chat preparation. Neither creates a native chat by itself. Never put tokens in URLs, plugin ZIPs or repositories.

## Other devices

The Ideas MCP App is responsive at phone, tablet and desktop widths. Its global entrypoint is available where the host supports plugin sidebar apps. Native Codex chat creation also requires that host's native thread tools.

For remote clients, configure private HTTPS forwarding to this loopback service and connect to /mcp with the owner token. The example remote MCP configuration contains placeholders only. The page makes tool calls through its host bridge, so it does not require filesystem or direct localhost access on a phone. Keep the Mac awake and reachable. This repository does not enable public ingress or install mobile plugins automatically.

OpenAI's public directory currently requires a remote HTTPS MCP service, publisher/domain verification, authentication, reviewer access, and approval. This release is source for manual local installation, not an approved directory listing. Local installs do not automatically become available in ChatGPT web/mobile. See https://developers.openai.com/plugins/deploy/submission and https://help.openai.com/en/articles/20001256-plugins-in-chatgpt.

## Share receivers

Native Mac and iPhone/iPad companion and Share extension sources are included. Their App Group and bundle IDs require your own Apple team provisioning before device installation. Offline outboxes retain capture UUIDs for safe retry. Source availability does not imply mobile Share extensions have been installed.

## Validation

```sh
npm test
```

Tests use disposable source fixtures and random loopback ports. They cover durable capture/readback, safe retries, source identities, freshness, explicit chat claims, exact native links, source counts/search/pagination, auth boundaries and both stdio/HTTP MCP. No tests modify the owner's Apple records or create real chats.

OpenAI's unmodified @openai/mcp-extensions 0.1.0 stylesheet and MIT license are in plugin/styles.

## Project and support

[Project](https://jaack.me/projects/ideas/) · [Support](https://jaack.me/ideas/support/) · [Privacy](https://jaack.me/ideas/privacy/) · [Use terms](https://jaack.me/ideas/terms/).

Each installer runs the service on their own Mac. This is a source preview requiring the tools listed above, not a signed one-click installer or an approved public-directory release. Version 0.2.1 adds portable public metadata and icons; the local source behavior is unchanged from 0.2.0. Plugin installation alone does not build or start the native companion.
