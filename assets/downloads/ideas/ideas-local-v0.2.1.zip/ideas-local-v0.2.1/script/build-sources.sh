#!/bin/zsh -f
set -euo pipefail
root=${0:A:h:h}
derived=${THREAD_INBOX_SOURCES_BUILD:-$root/.build/sources}
cd "$root"
xcodegen generate --spec apple/project.yml
BUILD=(xcodebuild -jobs 4)
if [[ -n ${THREAD_INBOX_BUILD_WRAPPER:-} ]]; then BUILD=("$THREAD_INBOX_BUILD_WRAPPER"); fi
"${BUILD[@]}" -project apple/ThreadInbox.xcodeproj -scheme IdeasSources -configuration Release -derivedDataPath "$derived" -destination 'platform=macOS' CODE_SIGNING_ALLOWED=NO build
/usr/bin/ditto "$derived/Build/Products/Release/Ideas Sources.app" "$root/Ideas Sources.app"
/usr/bin/codesign --force --sign - "$root/Ideas Sources.app"
/usr/bin/codesign --verify --strict "$root/Ideas Sources.app"
