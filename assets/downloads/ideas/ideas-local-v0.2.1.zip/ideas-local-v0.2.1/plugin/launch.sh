#!/bin/zsh -f
set -euo pipefail
root=${0:A:h}
for candidate in /opt/homebrew/opt/node/bin/node /usr/local/opt/node/bin/node; do
  if [[ -x "$candidate" ]]; then exec "$candidate" "$root/server.mjs"; fi
done
if (( $+commands[node] )); then exec node "$root/server.mjs"; fi
print -ru2 -- "Ideas requires Node 22.13 or later. Install Node and reopen the plugin."
exit 1
