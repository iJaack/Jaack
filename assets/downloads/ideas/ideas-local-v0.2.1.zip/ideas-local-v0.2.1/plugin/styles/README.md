Codex MCP App styles vendored without modification from @openai/mcp-extensions 0.1.0, package/styles.css. MIT license in LICENSE. Source: https://github.com/openai/mcp-extensions
The resource embeds these styles and inherits host theme variables through ui/initialize and host-context-changed.
