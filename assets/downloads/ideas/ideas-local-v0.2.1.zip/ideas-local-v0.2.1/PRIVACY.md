# Privacy

Ideas stores captures, source snapshots and chat links in a private SQLite file on the owner's Mac. The Calendar and Reminders connector reads local EventKit sources only after macOS permission is granted; it does not edit or complete them. Only authorized clients can read this inbox. Capture-device tokens cannot manage Mac permissions or native chat claims.

Tool results, including listed source records and full item details, are returned to the plugin host when its tools are called. Selected context is also included when the owner requests a chat. The host's data policies also apply. Sharing this source release does not share an inbox or tokens. The code does not fetch shared URLs or include analytics.

The owner controls backups and deletion. Uninstalling the plugin alone preserves its local inbox. Stop the dedicated LaunchAgent before deleting local inbox data. Mobile companion outboxes must be managed separately.

This document describes the self-hosted release. Any future hosted edition needs its own published policies, account isolation and authentication before directory submission.
